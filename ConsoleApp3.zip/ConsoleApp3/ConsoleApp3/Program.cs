﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("What's your name? ");
            string name = Console.ReadLine();
            Console.WriteLine($" Hello, {name}");
            DateTime date1 = new DateTime(2022, 1, 19);
            Console.WriteLine($"Today {date1.ToShortDateString()}");
        }
    }
}
